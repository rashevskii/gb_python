# number = int(input('Введите цифру от 1 до 9: '))

number = 3

print(number + (number * 11) + (number * 111))
