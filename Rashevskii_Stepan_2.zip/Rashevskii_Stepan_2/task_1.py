my_list = [2, 'two', 3.15, True, [1, 2], ('one', 'two'), {'one': 1, 'two': 2}]

for elem in my_list:
    print(type(elem))
