my_list = [7, 5, 3, 3, 2]

# number = int(input('Введите число: '))
number = 9

my_list.append(number)
my_list.sort(reverse=True)

print(my_list)
