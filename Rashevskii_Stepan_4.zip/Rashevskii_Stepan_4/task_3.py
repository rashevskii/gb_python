nums = list((el for el in range(20, 240) if not el % 20 or not el % 21))

print(nums)
